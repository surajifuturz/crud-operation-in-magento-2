<?php

namespace Creative\Digital\Model;

/**
 * Task Model
 *
 * @method \Iverve\Task\Model\Resource\Page _getResource()
 * @method \Iverve\Task\Model\Resource\Page getResource()
 */
class Digital extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Creative\Digital\Model\ResourceModel\Digital');
    }

}
