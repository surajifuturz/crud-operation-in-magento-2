<?php

/**
 * Task Resource Collection
 */
namespace Creative\Digital\Model\ResourceModel\Digital;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Creative\Digital\Model\Digital', 'Creative\Digital\Model\ResourceModel\Digital');
    }
}
