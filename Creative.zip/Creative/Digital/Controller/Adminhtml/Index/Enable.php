<?php

namespace Creative\Digital\Controller\Adminhtml\Index;

class Enable extends \Magento\Backend\App\Action
{
    const ADMIN_RESOURCE = 'Creative_Digital::digital_save';

    /**
     * @var string
     */
    protected $msgSuccess = 'Item was enabled.';

    /**
     * @var integer
     */
    protected $newStatusCode = 1;

    protected $digitalFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Creative\Digital\Model\DigitalFactory $digitalFactory
    ){
        $this->digitalFactory = $digitalFactory;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $id = $this->getRequest()->getParam('digital_id');
        if ($id) {
            try {
                $model = $this->digitalFactory->create();
                $model->load($id);
                $model->setStatus($this->newStatusCode);
                $model->save();
                $this->messageManager->addSuccess(__($this->msgSuccess, $model->getIdentifier()));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['digital_id' => $id]);
            }
        }

        return $resultRedirect->setPath('*/*/');
    }
}
