<?php
namespace Creative\Digital\Controller\Adminhtml\Index;

class Delete extends \Magento\Backend\App\Action
{
    const ADMIN_RESOURCE = 'Creative_Digital::digital_delete';

    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $id = $this->getRequest()->getParam('digital_id');
        if ($id) {
            try {
                $bannerModel = $this->_objectManager->create('Creative\Digital\Model\Digital');
                $bannerModel->load($id);
                $bannerModel->delete();
                $this->messageManager->addSuccess(__('Item was deleted.'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['digital_id' => $id]);
            }
        }

        return $resultRedirect->setPath('*/*/');
    }
}
