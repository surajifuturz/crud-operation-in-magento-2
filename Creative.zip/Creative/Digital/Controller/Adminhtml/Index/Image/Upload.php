<?php

namespace Creative\Digital\Controller\Adminhtml\Index\Image;

class Upload extends \Magento\Catalog\Controller\Adminhtml\Category\Image\Upload
{
    const ADMIN_RESOURCE = 'Creative_Digital::save';

    /**
     * @return boolean
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed(self::ADMIN_RESOURCE);
    }
}
