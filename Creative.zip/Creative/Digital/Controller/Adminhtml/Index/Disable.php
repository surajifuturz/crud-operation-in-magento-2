<?php

namespace Creative\Digital\Controller\Adminhtml\Index;

class Disable extends Enable
{
    /**
     * @var string
     */
    protected $msgSuccess = 'Item was disabled.';

    /**
     * @var integer
     */
    protected $newStatusCode = 0;
}
