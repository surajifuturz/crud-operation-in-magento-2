<?php

namespace Creative\Digital\Controller\Index;

use Magento\Framework\View\Result\PageFactory;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;

class Post extends \Magento\Framework\App\Action\Action
{
	/**
     * @var PageFactory
     */
    protected $resultPageFactory;
	
	 protected $_objectManager;
    protected $_storeManager;
    protected $_filesystem;
    protected $_fileUploaderFactory;
	
	/**
     * @param \Magento\Framework\App\Action\Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
		
		\Magento\Framework\ObjectManagerInterface $objectManager,
		\Magento\Framework\Filesystem $filesystem,
		\Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
		StoreManagerInterface $storeManager,
		
        PageFactory $resultPageFactory
    ) {
		
		$this->_objectManager = $objectManager;
        $this->_storeManager = $storeManager;
        $this->_filesystem = $filesystem;
        $this->_fileUploaderFactory = $fileUploaderFactory;
		
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
	
    /**
     * Default Careers Index page
     *
     * @return void
     */
    public function execute()
    {	
	
		$postdata = $this->getRequest()->getPost();
		
		if (!$postdata) {
            $this->_redirect('*/*/');
            return;
        }
		try {
		
			$data = $this->getRequest()->getPostValue();	     
			$question = $this->_objectManager->create('Creative\Digital\Model\Digital');
			$question->setData($data);
			$question->save();

            // Display the succes form validation message
           	$this->messageManager->addSuccess('Task Summit Successfully !');
			$this->_redirect('*/');
		}catch (\Exception $e) { 
            //$this->inlineTranslation->resume();
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical("error => ".$e->getMessage());
            $this->messageManager->addError(
                __('We can\'t process your request right now. Sorry, that\'s all we know.')
            );
          $this->_redirect('*/');
           return;
        }

       
        // Render the page 
        $this->_view->loadLayout();
        $this->_view->renderLayout();
	
        
    }
	
	
	
}
